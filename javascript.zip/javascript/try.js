let article = ["the","a","one","some", "any"];
let noun = ["boy","girl","dog","town","car"];
let verb = ["drove","jumped","ran","walked","skipped"];
let preposition = ["to","from","over","under","on"];

    const nextbtn = document.createElement('button');
    nextbtn.classList="sadf";
    

    const deletebtn = document.createElement('button');
    deletebtn.classList="adfa";
    deletebtn.innerHTML = "delete Sentence";

    let para = document.querySelector('p');

function sentence(){
     
   
   
    for(let i=0;i<20;i++){
        var sentences = "";
      
        let a=article[(Math.floor(Math.random()*5))];
        let n=noun[(Math.floor(Math.random()*5))];
        let v=verb[(Math.floor(Math.random()*5))];
        let p=preposition[(Math.floor(Math.random()*5))];
        let ar=article[(Math.floor(Math.random()*5))];
        let nr=article[(Math.floor(Math.random()*5))];
        
        sentences+=a + " " +n+" "+v+" "+p+" "+ar+" "+nr;

        const splitsentence = sentences.split(' ');
        const sortsentence = splitsentence.sort();
        const joinsentence = sortsentence.join(' ') + ".";
        const firstCapital = joinsentence.charAt(0).toUpperCase();
        const others = firstCapital + joinsentence.substring(joinsentence.length, 1);
        const newelement=document.createElement("p");
        newelement.classList="text-white text-center";
        const br=document.createElement("br")     
        newelement.innerHTML=others;
        newelement.appendChild(br);
        para.appendChild(newelement);
        para.style.textAlign="center";        
        
    }
        
        para.appendChild(nextbtn);
        para.appendChild(deletebtn);
        
}
nextbtn.addEventListener("click", nextLine);
deletebtn.addEventListener("click", deleteLine);


function nextLine(){
    sentence();
}
function deleteLine(){
    para.remove();
}


console.log(sentence())